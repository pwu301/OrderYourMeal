package sample.android.menu;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class ProgressThread extends Thread {
	
	Handler handler;
    final static int STATE_DONE = 0;
    final static int STATE_RUNNING = 1;
    int state;
    int total;
   
    ProgressThread(Handler h) {
        handler = h;
    }
   
    public void run() {
        state = STATE_RUNNING;   
        total = 0;
        while (state == STATE_RUNNING) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Log.e("ERROR", "Thread Interrupted");
            }
            Message msg = handler.obtainMessage();
            msg.arg1 = total;
            handler.sendMessage(msg);
            total++;
        }
    }
    
    /* sets the current state for the thread,
     * used to stop the thread */
    public void setState(int state) {
        this.state = state;
    }

}
