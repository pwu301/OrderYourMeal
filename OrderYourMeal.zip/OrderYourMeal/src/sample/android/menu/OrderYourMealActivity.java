package sample.android.menu;

import sample.android.menu.R;
 
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class OrderYourMealActivity extends Activity {
	
	private LinearLayout.LayoutParams layoutParams;
	private LinearLayout.LayoutParams widgetParams;
	private LinearLayout root;
	private TextView initText;
	private TextView[] textView = new TextView[5];
	private ArrayAdapter[] adapter = new ArrayAdapter[5];
	private Spinner[] spinner = new Spinner[5];
	private String[] selectlist = new String[5];
	private static final int DIALOG_LIST = 1;
	private static final int DIALOG_YES_NO_SUBMIT_PROGRESS = 2;
	private static final int DIALOG_YES_NO_RESET = 3;

	private static final int MAX_PROGRESS = 100;

	private AlertDialog listDialog;
    private ProgressDialog progressDialog;

    //private Handler progressHandler;
    private ProgressThread progressThread;

    final Handler progressHandler = new Handler() {
        public void handleMessage(Message msg) {
            int total = msg.arg1;
            progressDialog.setProgress(total);
            if (total >= 100){
                dismissDialog(DIALOG_YES_NO_SUBMIT_PROGRESS);
                progressThread.setState(ProgressThread.STATE_DONE);
            }
        }
    };
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        
        
      //Parameters common to all or most of my layouts.
		layoutParams = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,		//width
				ViewGroup.LayoutParams.WRAP_CONTENT,	//height
				0.0f									//weight
		);

		//Parameters common to all or most of my widgets.
		widgetParams = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,		//width
				ViewGroup.LayoutParams.WRAP_CONTENT,	//height
				0.0f									//weight
		);

		root = new LinearLayout(this);
		root.setLayoutParams(layoutParams);
		root.setOrientation(LinearLayout.VERTICAL);
				
		//TextView
		initText = new TextView(this);
		initText.setLayoutParams(widgetParams);
		initText.setText("Press the menu to preview, submit, and reset order.");		
		root.addView(initText);

		//initialize adapter and spinner
		setSpinnerView();
		setContentView(root);

    }
    
    protected void setSpinnerView(){
    	
    	for (int i=0; i<spinner.length; i++) {
    	textView[i] = new TextView(this);
		textView[i].setLayoutParams(widgetParams);		
		textView[i].setTextColor(Color.GREEN);
	    root.addView(textView[i]);

		spinner[i] = new Spinner(this);
		spinner[i].setLayoutParams(widgetParams);
        root.addView(spinner[i]);
    	}
    	
		textView[0].setText(R.string.catalog0_name);
		adapter[0] = ArrayAdapter.createFromResource(
                this, R.array.catalog0, android.R.layout.simple_spinner_item);
        adapter[0].setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner[0].setAdapter(adapter[0]);
        spinner[0].setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                            AdapterView<?> parent, View view, int position, long id) {
                    	selectlist[0] = (String)parent.getSelectedItem();
                    }
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
         });
        
		textView[1].setText(R.string.catalog1_name);
		adapter[1] = ArrayAdapter.createFromResource(
                this, R.array.catalog1, android.R.layout.simple_spinner_item);
        adapter[1].setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner[1].setAdapter(adapter[1]);
        spinner[1].setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                            AdapterView<?> parent, View view, int position, long id) {
                    	selectlist[1] = (String)parent.getSelectedItem();
                    }
                    public void onNothingSelected(AdapterView<?> parent) {
                    	
                    }
         });

		textView[2].setText(R.string.catalog2_name);
		adapter[2] = ArrayAdapter.createFromResource(
                this, R.array.catalog2, android.R.layout.simple_spinner_item);
        adapter[2].setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner[2].setAdapter(adapter[2]);
        spinner[2].setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                            AdapterView<?> parent, View view, int position, long id) {
                    	selectlist[2] = (String)parent.getSelectedItem();
                    }
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
         });

		textView[3].setText(R.string.catalog3_name);
		adapter[3] = ArrayAdapter.createFromResource(
                this, R.array.catalog3, android.R.layout.simple_spinner_item);
        adapter[3].setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner[3].setAdapter(adapter[3]);
        spinner[3].setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                            AdapterView<?> parent, View view, int position, long id) {
                    	selectlist[3] = (String)parent.getSelectedItem();
                    }
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
         });

		textView[4].setText(R.string.catalog4_name);
		adapter[4] = ArrayAdapter.createFromResource(
                this, R.array.catalog4, android.R.layout.simple_spinner_item);
        adapter[4].setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner[4].setAdapter(adapter[4]);
        spinner[4].setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                            AdapterView<?> parent, View view, int position, long id) {
                    	selectlist[4] = (String)parent.getSelectedItem();
                    }
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
         });
        
    }
    
	protected void showToast(String string) {
		// TODO Auto-generated method stub
		Toast.makeText(this, string, Toast.LENGTH_SHORT).show();
	}

	@Override
	protected void onPrepareDialog(int id, Dialog dialog) {
		switch(id) {
		
		    case DIALOG_LIST:
        	     for (int i=0; i<spinner.length; i++) {
        	    	 Log.i("SelectList", selectlist[i]);
        	     }

        	     break;
			case DIALOG_YES_NO_SUBMIT_PROGRESS:
				progressDialog.setProgress(0);
				progressThread = new ProgressThread(progressHandler);
				progressThread.start();
				break;

			default:
				break;
	    }
	}

	@Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {

        case DIALOG_LIST:
            return new AlertDialog.Builder(this)
                .setTitle(R.string.select_dialog)
                .setItems(selectlist, new DialogInterface.OnClickListener() {
                     public void onClick(DialogInterface dialog, int which) {
                     }
                 })
                .setPositiveButton(R.string.alert_dialog_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    	dialog.dismiss();
                    }
                })
                .create();
            
           
        case DIALOG_YES_NO_SUBMIT_PROGRESS:
            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle(R.string.submit_dialog);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.setMax(MAX_PROGRESS);
			progressDialog.setMessage("Submitting ...");
            progressDialog.setButton(DialogInterface.BUTTON_NEGATIVE,
                    getText(R.string.alert_dialog_cancel), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    progressThread.setState(ProgressThread.STATE_DONE);
                }
            });
            return progressDialog;

        case DIALOG_YES_NO_RESET:
            return new AlertDialog.Builder(this)
                .setTitle(R.string.reset_dialog)
                .setPositiveButton(R.string.alert_dialog_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                    	for (int i=0; i<spinner.length; i++){
                            spinner[i].setSelection(0);
                        }
                    }
                })
                .setNegativeButton(R.string.alert_dialog_cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        //do nothing.
                    }
                })
                .create();
        }
        return null;
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.optionsmenu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection

		switch (item.getItemId()) {
  
		case R.id.preview:
			//Display list of the items ordered;
			showDialog(DIALOG_LIST);
			return true;
			
		case R.id.submit:
			//Submit order;
			showDialog(DIALOG_YES_NO_SUBMIT_PROGRESS);
			return true;

		case R.id.reset:
			//Reset the selection and return to the beginning page;
			showDialog(DIALOG_YES_NO_RESET);
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	


}